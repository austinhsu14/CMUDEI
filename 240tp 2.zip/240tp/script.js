function changeImage(imgid, source) {
    /* changes source for specified image */
    document.getElementById(imgid).src = source;
}